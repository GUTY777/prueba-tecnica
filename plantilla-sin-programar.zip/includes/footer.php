<footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-3 logo">
                    <a href="">
                        <img src="assets/images/logo.png" alt="Logo" title="Logo">
                        <span>Hlo21</span>
                    </a>
                </div>
                <div class="col-xs-12 col-sm-3 menu">
                    <h3>Menu</h3>
                    <ul>
                        <li><a href="">Inicio</a></li>
                        <li><a href="">Nosotros</a></li>
                        <li><a href="">Blog</a></li>
                        <li><a href="">Contactenos</a></li>
                    </ul>
                </div>
                <div class="col-xs-12 col-sm-3 menu">
                    <h3>Mensaje</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime, accusantium at vel sed ipsam
                        vitae similique, optio eligendi ipsum tempore laudantium quis. Pariatur adipisci officiis
                        maxime, ab nobis ipsam iste.</p>
                </div>
                <div class="col-xs-12 col-sm-3 redes">
                    <a href="">
                        <i class="fab fa-facebook"></i>
                    </a>
                    <a href="">
                        <i class="fab fa-instagram"></i>
                    </a>
                    <a href="">
                        <i class="fab fa-twitter"></i>
                    </a>
                </div>
            </div>
        </div>
    </footer>
    <script src="assets/js/jquery-3.4.1.min.js"></script>
    <script src="assets/owlcarousel/owl.carousel.min.js"></script>
    <script src="assets/js/init.js"></script>