<?php include "includes/head.php"; ?>
<body>
    <?php include "includes/menu.php"; ?>
    <div class="contenido divinicio">
        <h1 class="titles pad-left pad-right"><span>Inicio</span></h1>
        <div class="container">
            <div class="migaPan">
                <span>Inicio</span>
            </div>
            <img src="assets/img/chart.png" alt="">
        </div>
    </div>
    <?php include "includes/footer.php"; ?>
</body>
</html>