<script src="assets/js/jquery-3.4.1.min.js"></script>
<script src="https://kit.fontawesome.com/c645c36a82.js"></script>
<link rel="stylesheet" href="assets/css/froala_editor.pkgd.min.css">
<script src="assets/js/froala_editor.pkgd.min.js"></script>
<script src='assets/js/languages/es.js'></script>
<script src="assets/js/init.js"></script>