<?php 
    $menu = $_SERVER['PHP_SELF'];
    $menu = explode("/",$menu);
    $menu = end($menu);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Administrador</title>
    <link rel="stylesheet" href="assets/css/flexboxgrid.min.css"> 
    <link rel="stylesheet" href="assets/css/style.css">
</head>