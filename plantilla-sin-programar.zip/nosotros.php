<?php 
    include "includes/head.php";
?>
<body>
    <?php 
       include "includes/menu.php";
    ?>
    <div class="divnosotros">
        <div class="container">
            <h1 class="text-center">Sobre nosotros</h1>
            <p><img src="assets/images/blog1.jpg" alt="Sobre nosotros" title="Sobre nosotros" class="imgIzquierda">
                Lorem
                ipsum dolor sit
                amet consectetur adipisicing
                elit.
                Dolores mollitia eveniet doloribus voluptatum
                magni, quae quas minima quod autem neque tempora at iste aliquid consequatur quaerat numquam quis cumque
                nemo. Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores mollitia eveniet doloribus
                voluptatum
                magni, quae quas minima quod autem neque tempora at iste aliquid consequatur quaerat numquam quis cumque
                nemo. Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores mollitia eveniet doloribus
                voluptatum
                magni, quae quas minima quod autem neque tempora at iste aliquid consequatur quaerat numquam quis cumque
                nemo. Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores mollitia eveniet doloribus
                voluptatum
                magni, quae quas minima quod autem neque tempora at iste aliquid consequatur quaerat numquam quis cumque
                nemo.</p>

            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores mollitia eveniet doloribus voluptatum
                magni, quae quas minima quod autem neque tempora at iste aliquid consequatur quaerat numquam quis cumque
                nemo. Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores mollitia eveniet doloribus
                voluptatum
                magni, quae quas minima quod autem neque tempora at iste aliquid consequatur quaerat numquam quis cumque
                nemo. Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores mollitia eveniet doloribus
                voluptatum
                magni, quae quas minima quod autem neque tempora at iste aliquid consequatur quaerat numquam quis cumque
                nemo. Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores mollitia eveniet doloribus
                voluptatum
                magni, quae quas minima quod autem neque tempora at iste aliquid consequatur quaerat numquam quis cumque
                nemo.
            </p>
            <p> <img src="assets/images/blog1.jpg" alt="Sobre nosotros" title="Sobre nosotros" class="imgDerecha">Lorem
                ipsum dolor sit amet consectetur adipisicing elit. Dolores mollitia eveniet doloribus voluptatum
                magni, quae quas minima quod autem neque tempora at iste aliquid consequatur quaerat numquam quis cumque
                nemo. Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores mollitia eveniet doloribus
                voluptatum
                magni, quae quas minima quod autem neque tempora at iste aliquid consequatur quaerat numquam quis cumque
                nemo. Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores mollitia eveniet doloribus
                voluptatum
                magni, quae quas minima quod autem neque tempora at iste aliquid consequatur quaerat numquam quis cumque
                nemo. Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores mollitia eveniet doloribus
                voluptatum
                magni, quae quas minima quod autem neque tempora at iste aliquid consequatur quaerat numquam quis cumque
                nemo.
            </p>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores mollitia eveniet doloribus voluptatum
                magni, quae quas minima quod autem neque tempora at iste aliquid consequatur quaerat numquam quis cumque
                nemo. Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores mollitia eveniet doloribus
                voluptatum
                magni, quae quas minima quod autem neque tempora at iste aliquid consequatur quaerat numquam quis cumque
                nemo. Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores mollitia eveniet doloribus
                voluptatum
                magni, quae quas minima quod autem neque tempora at iste aliquid consequatur quaerat numquam quis cumque
                nemo. Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores mollitia eveniet doloribus
                voluptatum
                magni, quae quas minima quod autem neque tempora at iste aliquid consequatur quaerat numquam quis cumque
                nemo.</p>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores mollitia eveniet doloribus voluptatum
                magni, quae quas minima quod autem neque tempora at iste aliquid consequatur quaerat numquam quis cumque
                nemo. Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores mollitia eveniet doloribus
                voluptatum
                magni, quae quas minima quod autem neque tempora at iste aliquid consequatur quaerat numquam quis cumque
                nemo. Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores mollitia eveniet doloribus
                voluptatum
                magni, quae quas minima quod autem neque tempora at iste aliquid consequatur quaerat numquam quis cumque
                nemo. Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores mollitia eveniet doloribus
                voluptatum
                magni, quae quas minima quod autem neque tempora at iste aliquid consequatur quaerat numquam quis cumque
                nemo.</p>
        </div>
    </div>

    <div class="divsuscribete">
        <div class="container">
            <h3>Suscribete</h3>
            <form action="">
                <input type="email" placeholder="Email">
                <button><i class="fa fa-envelope"></i></button>
            </form>
            <p>Suscribete para optener notificaciónes de noticias en tu bandeja de entrada.</p>
        </div>
    </div>
    <?php 
        include "includes/footer.php";
    ?>
</body>

</html>